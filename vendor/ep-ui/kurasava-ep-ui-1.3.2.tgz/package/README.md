# EP UI 1.3

Переиспользуемая UI-библиотека на основе визуального стиля **EP Modpack Updater** из предоставленного архива. 37 React-компонентов, TypeScript, CSS без Tailwind, 12 цветовых акцентов и офлайн-каталог.

## Начните здесь

1. Откройте `catalog.html` двойным щелчком. Интернет и сервер не нужны. В каталоге работают смена акцента, поиск, фильтры, создание демонстрационных проектов, окна и переключатели. Изменения в каталоге живут до перезагрузки страницы.
2. Установите `kurasava-ep-ui-1.3.2.tgz` в свой React-проект:

```sh
npm install ./kurasava-ep-ui-1.3.2.tgz
```

Путь указывает на скачанный файл. В публичный npm пакет не опубликован. React и React DOM должны быть установлены в проекте: поддерживается диапазон 18.3 / 19; сборка и проверки выполнены с React 18.3.1. Для редактирования самой библиотеки: `npm ci`, `npm run build`, `npm run demo:build`.

```tsx
import { Theme, Button, Card, Field, Input } from '@kurasava/ep-ui';
import '@kurasava/ep-ui/styles.css';

export function App() {
  return (
    <Theme accent="purple" style={{ minHeight: '100vh', padding: 24 }}>
      <Card className="ep-stack">
        <Field label="Название" required>
          {props => <Input {...props} placeholder="Новый проект" />}
        </Field>
        <Button onClick={() => console.log('save')}>Сохранить</Button>
      </Card>
    </Theme>
  );
}
```

Все компоненты помещайте внутрь `Theme`. CSS нужно импортировать один раз. В Next.js импортируйте CSS в корневом layout, а компоненты с событиями используйте в клиентском компоненте. Пакет содержит `use client`. Electron использует тот же код в renderer; доступа к Node, IPC или файловой системе библиотека не требует.

## Что сохранено из приложения

- Gray 950 `#030712` — фон; Gray 900 `#111827` — панели; Gray 800 `#1f2937` — приподнятые поверхности и границы.
- Purple 600 `#9333ea` — основное действие; Purple 700 `#7e22ce` — наведение; Purple 500 `#a855f7` — фокус.
- Радиусы 8 / 12 / 16 px, карточки с отступом 24 px, заголовки 30 / 20 / 18 px.
- Цветные карточки: фон 5%, граница 30%, при наведении 10% / 60%, подъём на 4 px и цветная тень.
- Полупрозрачная шапка, затемнённая размытая подложка модального окна, тёмные поля, варианты кнопок, палитра из 12 цветов.
- Шрифт Inter → системный sans-serif. Файл Inter не включён и автоматически из сети не загружается; при необходимости подключите его в своём проекте.

Технически компоненты переписаны для независимого использования. Убраны доменные типы, Minecraft, API, IPC, i18n-контекст, Tailwind, Framer Motion и обязательные иконки. Тексты и иконки передаются через props. В 1.1 восстановлен кастомный Dropdown из исходника. Select использует это же меню и сохраняет onChange(event) и участие в HTML-формах. Фон меню #1f2937/95%, рамка #374151, выделение #4b5563. При наличии используется Popover API. Без него меню выводится через React portal в body или в открытый dialog с сохранением переменных темы. Для окон используется нативный `dialog` с фокусом и модальностью. Зелёные кнопки немного затемнены ради читаемости белого текста. Чекбокс перенесён из LaunchSettingsModal (20×20 px, SVG 12 px); Switch из EditModModal (40×20 px, ползунок 16 px, отступ 2 px); Table и Field оформлены по той же теме. Это библиотека стиля, не побайтовая копия приложения.

## Компоненты и API

Все публичные типы экспортируются из пакета. Стандартные компоненты поддерживают обычные DOM-атрибуты и `className`; `Button`, `IconButton`, `Input`, `Textarea`, `Select`, `SearchInput`, `Checkbox`, `Switch`, `Card`, `Theme` передают `ref`.

| Компонент | Основные props / назначение |
|---|---|
| `Sidebar` | items, activeId, onActiveChange, label, header/footer, collapsed, onCollapsedChange |
| `MenuBar` | menus: MenuBarEntry[], label; горизонтальная строка меню |
| `StatusBar` | message, items: StatusBarItem[]; состояние и быстрые действия |
| `NumberInput` | value: number/null, onValueChange, min/max/step, unit; кастомные кнопки |
| `Slider` | value/defaultValue, onValueChange, min/max/step, showValue, formatValue, accent |
| `RadioGroup` | label, options, value/defaultValue, onValueChange, name, required, disabled, orientation |
| `Combobox` | value, onChange(value), options: string[], onSelectValue?, emptyText; ввод с подсказками и свободным текстом |
| `Tooltip` | content, children (один фокусируемый элемент), delay=350, side=top/bottom, disabled |
| `DropdownMenu` | trigger (кнопка), items: MenuItem[], label |
| `ContextMenu` | items, label, children; правая кнопка / Shift+F10 |
| `Toast` | title, message, tone, duration, action, onDismiss; отдельное сообщение |
| `ToastProvider` | maxVisible=3, duration=4500, position, label, closeLabel; очередь сообщений |
| `Theme` | `accent?: Tone`, `density?: 'comfortable' \| 'compact'`, `style?: ThemeStyle`; граница действия стилей |
| `Button` | `variant`, `size: sm/md/lg`, `icon`, `loading`, `disabled`; по умолчанию `type="button"` |
| `CloseButton` | Обязательный aria-label; прозрачный фон, 32×32 px, SVG-крестик 20 px |
| `Dropdown` | value, onChange(value), options, placeholder, label, size: sm/md; кастомный список |
| `TitleBar` | title, logo, onMinimize, onMaximize, onClose; onBack, maximized, labels, draggable |
| `IconButton` | `icon`, обязательный `aria-label`, остальные props Button |
| `Input` | Стандартный input; `type`, `value`, `onChange`, `disabled`, `aria-invalid` |
| `Textarea` | Стандартная многострочная форма |
| `Select` | `options: {value, label, disabled?}[]` или дочерние option; кастомное меню, стандартный onChange(event), controlSize: sm/md |
| `Field` | `label`, `hint`, `error`, `required`; render-функция передаёт id и атрибуты доступности полю |
| `SearchInput` | `value`, `onValueChange`, обязательный `clearLabel`; передайте `aria-label` или связанный label |
| `Checkbox` | `label`, стандартные `checked`, `defaultChecked`, `onChange`, `disabled` |
| `Switch` | То же, что Checkbox; `role="switch"` |
| `Card` | `tone?: Tone`, `interactive?: boolean`; interactive включает эффект наведения, не добавляет событие открытия |
| `Badge` | `tone?: Tone`, children |
| `Alert` | `tone`, `heading`, children; `role="status"` по умолчанию, `role="alert"` для срочного сообщения |
| `Progress` | обязательный `label`, `value?`, `max=100`; без value — неопределённый прогресс |
| `Tabs` | `items: {value,label,content,disabled?}[]`, `value`, `onValueChange`, `label` |
| `Modal` | `open`, `onClose`, `title`, `closeLabel`, `description?`, `footer?`, `size: sm/md/lg`, `closeOnBackdrop` |
| `ConfirmDialog` | Modal + `onConfirm`, `confirmLabel`, `cancelLabel`, `busy`, `danger`; отмена получает первоначальный фокус |
| `PageHeader` | `title`, `description`, `eyebrow`, `actions` |
| `Toolbar` | Обёртка для поиска, фильтров и действий |
| `EmptyState` | `title`, `description`, `icon`, `action` |
| `ColorPicker` | `value` — HEX, `onValueChange`, `label`, `colors?: {value,label}[]`, `customLabel?` включает произвольный цвет |
| `Table` | `caption`, `headers`, children — строки `<tr><td>…`; горизонтальная прокрутка |

`Variant`: primary, secondary, danger, success, info, warning, cancel, ghost.

`Tone`: purple, blue, green, orange, red, gray, pink, yellow, cyan, lime, indigo, violet.

`palette` — экспортированный словарь Tone → HEX. По умолчанию ColorPicker использует английские названия цветов: для локализации передайте `colors` со своими label.

`Tabs` — управляемый компонент: передавайте value существующей доступной вкладки и обновляйте его через onValueChange. Стрелки ← →, Home и End переключают вкладки. Скрытые панели сохраняются в DOM, чтобы не терять локальное состояние форм.

`Modal` и `ConfirmDialog` — управляемые компоненты: в onClose меняйте open на false. Окно закрывается через Escape и клик снаружи; нативный dialog удерживает фокус и блокирует взаимодействие с фоном. У длинного окна прокручивается тело. Для первоначального фокуса при каждом открытии добавьте полю `data-ep-autofocus`. Не рендерите содержимое окна отдельным порталом за пределы Theme: оно должно наследовать переменные темы. Одновременно показывайте одно окно. Общий scroll-lock страницы не устанавливается.

`ConfirmDialog`: async-операцию выполняет ваш код. Передайте busy на время ожидания и закройте окно после успеха; при ошибке оставьте его открытым и покажите Alert. Во время busy закрытие и повторное подтверждение блокируются.

## Настройка темы

```tsx
<Theme accent="blue" density="compact" style={{
  '--ep-radius-sm': '6px',
  '--ep-radius-md': '10px',
  '--ep-radius-lg': '14px',
  '--ep-font': 'Arial, sans-serif',
}}>
  {children}
</Theme>
```

Можно определить свою тему в CSS, подключённом после библиотеки:

```css
.ep-ui.my-theme {
  --ep-primary: #0f766e;
  --ep-primary-hover: #115e59;
  --ep-primary-rgb: 15 118 110;
  --ep-focus: #5eead4;
}
```

Для переопределения акцента с className используйте селектор `.ep-ui.my-theme` (его специфичность равна селектору предустановки), либо inline `style`. `--ep-primary-rgb` содержит три числа через пробел. Главные переменные: `--ep-bg`, `--ep-surface`, `--ep-surface-raised`, `--ep-control`, `--ep-control-hover`, `--ep-border`, `--ep-input-border`, `--ep-text`, `--ep-muted`, `--ep-primary`, `--ep-primary-hover`, `--ep-primary-rgb`, `--ep-focus`, `--ep-radius-sm/md/lg`, `--ep-space`, `--ep-font`, `--ep-duration`.

В `tokens.json` находятся базовые значения и исходная палитра. Источник истины для исполняемой темы — `src/styles.css`; при изменениях обновляйте tokens.json вместе с ним.

## Использование без React

Скопируйте `dist/styles.css` в свой проект, подключите обычным link и используйте классы:

```html
<link rel="stylesheet" href="./styles.css">
<div class="ep-ui" data-accent="purple">
  <div class="ep-card ep-stack">
    <label class="ep-label" for="name">Название</label>
    <input class="ep-input" id="name" placeholder="Новый проект">
    <button type="button" class="ep-button ep-button--primary ep-button--md">Сохранить</button>
  </div>
</div>
```

Пример `examples/plain-html.html` работает без сборки. Vue/Svelte используют те же CSS-классы; поведение вкладок, модальных окон и поиска нужно реализовать в своём фреймворке. Набор Vue/Svelte-компонентов не включён. Утилиты: `ep-row`, `ep-stack`, `ep-grid`, `ep-muted`, `ep-label`, `ep-error`.

## Практические правила

- Для кликабельной карточки помещайте внутри кнопку или ссылку. `interactive` сам по себе не делает div доступной кнопкой.
- Кнопке сохранения формы задавайте `type="submit"` явно.
- Не используйте placeholder как единственную подпись поля. Field связывает label, hint и error автоматически.
- Стили ограничены `.ep-ui`; не меняются body и #root хост-приложения. Нормализация потомков действует внутри Theme, что следует учитывать при размещении чужих виджетов в этой области.
- Тёмная тема — исходная. Светлая тема отдельно не спроектирована.
- Нужны native dialog и CSS RGB с alpha. Popover API необязателен: с 1.3.1 предусмотрен fallback для браузеров без showPopover. Internet Explorer и старые WebView не поддерживаются.
- Все эффекты отключаются при prefers-reduced-motion. Внешних запросов библиотека не делает.
- Реализованы доступные подписи и клавиатурное управление; это не сертификат полного WCAG-аудита.

## Структура и разработка

```text
src/index.tsx         компоненты и типы
src/styles.css       готовая тема и компоненты CSS
dist/                собранный ESM-пакет, типы, CSS
tokens.json          дизайн-токены для переноса
demo/                исходник интерактивного каталога
catalog.html         готовый автономный каталог
examples/            минимальный пример без React
scripts/             сборка и браузерные проверки
README.md            установка и API
DESIGN-MAPPING.md    связь с исходным приложением
VALIDATION.md        результаты проверки
```

```sh
npm ci
npm run typecheck
npm run build
npm run demo:build
npm pack
# Браузерные проверки (дополнительный инструмент):
npm install --no-save playwright
npx playwright install chromium
npm test
```

Собранный пакет — ESM. CommonJS require не предоставляется. Для изменения интерфейса правьте src, пересобирайте и заново устанавливайте tgz в проект-потребитель. Не копируйте node_modules. Для работы команды npm install при отсутствии зависимостей требуется доступ к npm.


## Изменения 1.1: исходный визуал и настольные приложения

Откройте `EP-UI-Playground.html`: актуальная витрина со всеми исправлениями и разделом Desktop. `catalog.html` — компактный каталог, также пересобран.

- CloseButton: фон только при hover, как в исходном CloseButton.tsx; в Modal top и right по 16 px от внутренней границы (17 px от внешнего края с учётом рамки). Равенство не зависит от переноса заголовка.
- Dropdown: исходное оформление; добавлены disabled-пункты, Arrow Up/Down, Home/End, Enter/Space, Escape и поиск набором текста. Открывается вверх при недостатке места снизу. Закрывается при наружном клике, Tab, прокрутке страницы или изменении размеров окна. Прокрутка самого меню его не закрывает. Внутри модального окна первый Escape закрывает список, следующий — окно.
- Select: тот же кастомный визуал с интерфейсом стандартного select для форм. Только одиночный выбор; для множественного списка используйте отдельный компонент в будущем. Переданный ref указывает на скрытый select для чтения значения; для управления фокусом кастомного триггера используйте Dropdown с ref. `className` и `style` применяются к триггеру, `name` и required — к полю формы. Подпись Field связана с видимой кнопкой. Список детей option/optgroup поддерживается в плоском меню без отдельных заголовков групп.
- Checkbox: собственный квадрат, галочка и недоступное состояние с минусом, как в LaunchSettingsModal. Сохранены нативные input, checked, required, name и клавиатура.
- Switch: геометрия и анимация из EditModModal; сохранена нативная семантика переключателя.
- TitleBar: высота 48 px; управляющие кнопки 32×32 px; вертикальные отступы 8 px; фон #1f2937; логотип #33a77d; крестик становится красным только при hover.

### TitleBar в Electron

```tsx
<TitleBar
  title="Моё приложение"
  logo="EP"
  maximized={isMaximized}
  onBack={goBack}
  onMinimize={() => window.electronAPI.minimizeWindow()}
  onMaximize={() => window.electronAPI.maximizeWindow()}
  onClose={() => window.electronAPI.closeWindow()}
/>
```

Это адаптер к методам из предоставленного исходного приложения. В новом проекте `electronAPI` и его TypeScript-декларацию предоставляет ваш preload; имена обработчиков могут быть другими. Используйте безрамочное окно и собственную интеграцию IPC. TitleBar не импортирует Electron и не получает доступ к Node автоматически. Обновляйте maximized из состояния окна. По умолчанию draggable=true включает `-webkit-app-region: drag`, а кнопки имеют no-drag. В веб-витрине draggable=false и команды показывают сообщение. Закрывать настоящее окно браузера эти кнопки не пытаются.

TitleBar располагается в обычном потоке (в исходнике был absolute): поместите сверху в вертикальный flex-контейнер, а рабочей области задайте flex:1 и min-height:0. При необходимости абсолютное позиционирование задаётся через className/style.

### Отдельный Dropdown

```tsx
const [value, setValue] = useState('one');
<Dropdown aria-label="Версия" label="Версия" size="sm"
  value={value} onChange={setValue}
  options={[{value:'one',label:'Первая'}, {value:'two',label:'Вторая'}]} />
```

Подтверждено браузерными тестами Chromium, включая меню в модальном окне и геометрию крестика. Реальное окно Electron в этом окружении не запускалось; callbacks TitleBar проверены в браузере.


## Новое в 1.2: поиск, подсказки, меню, уведомления

Шесть новых компонентов и hook useToast. Их живые примеры находятся в начале полной витрины `EP-UI-Playground.html`. Для каждого есть раскрываемый и копируемый код.

### Combobox

Перенесён визуал `components/ui/Combobox.tsx`: фон gray-900/80, граница gray-600, стрелка 16 px, меню gray-800/95, активный пункт primary/40. Подсказки фильтруются по вхождению текста без учёта регистра; повторяющиеся варианты исключаются.

```tsx
const [category, setCategory] = useState('');
<Field label="Категория">
  {props => <Combobox {...props} value={category} onChange={setCategory}
    options={['Интерфейс', 'Графика', 'Документы']}
    onSelectValue={value => console.log(value)} />}
</Field>
```

Это редактируемое поле, а не строгий справочник: произвольный введённый текст остаётся значением. Если нужны только разрешённые значения, проверяйте их в приложении либо используйте Select/Dropdown. Поддерживаются обычные атрибуты input, name, required, disabled и ref на input. onChange(value) вызывается при каждом вводе; onSelectValue(value) — только при выборе подсказки. Arrow Up/Down выбирают подсказки, Enter подтверждает, Escape закрывает меню, Tab продолжает обход формы. Для локализации задайте emptyText и toggleLabel. Виртуализации больших справочников нет.

### Tooltip

```tsx
<Tooltip content="Сохранить изменения" side="top" delay={350}>
  <Button onClick={save}>Сохранить</Button>
</Tooltip>
```

Передавайте один фокусируемый элемент, который прокидывает aria-describedby в DOM. Доступны hover, focus и Escape; при перемещении курсора на подсказку она остаётся видимой. На сенсорных устройствах важное пояснение должно быть доступно и без hover. Подсказка не заменяет aria-label кнопки-иконки. Контент Tooltip не должен содержать интерактивных элементов; для них нужен отдельный Popover. У disabled-кнопки браузер не даёт фокуса: используйте видимую подпись или доступную фокусируемую обёртку.

### Меню действий

```tsx
const items: MenuItem[] = [
  { id: 'open', label: 'Открыть', onSelect: open },
  { id: 'copy', label: 'Дублировать', onSelect: duplicate },
  { id: 'locked', label: 'Экспорт', disabled: true, onSelect: exportFile },
  { id: 'separator', separator: true },
  { id: 'delete', label: 'Удалить', danger: true, onSelect: remove },
];
<DropdownMenu label="Действия проекта" items={items}
  trigger={<Button variant="secondary">Действия</Button>} />
<ContextMenu label="Меню карточки" items={items}>
  <Card>Карточка проекта</Card>
</ContextMenu>
```

Для DropdownMenu передавайте одну кнопку, прокидывающую aria-* и события. MenuItem также принимает icon и shortcut (визуальная подпись сочетания; глобальный обработчик горячих клавиш не регистрируется). У каждого пункта должен быть уникальный id. Недоступные пункты пропускаются стрелками; доступны Home/End, поиск набором текста, Enter/Space, Escape. Выбор и Escape возвращают фокус к триггеру; внешний клик закрывает меню, оставляя фокус новой цели. ContextMenu открывается правой кнопкой и Shift+F10. Для телефонов показывайте DropdownMenu с тем же массивом items; long press отдельно не реализован. Подменю и пункты-переключатели пока не включены.

Меню использует Popover API, если он доступен; иначе — React portal с копированием CSS-переменных --ep-*. Внутри Modal портал остаётся в dialog, чтобы сохранить фокус и доступность. Tooltip и списки ограничены краями viewport, выбирают верхнее или нижнее расположение. При прокрутке Combobox/DropdownMenu/Tooltip пересчитывают позицию; контекстное меню закрывается. При изменении размера окна все закрываются.

### Уведомления

```tsx
<Theme>
  <ToastProvider maxVisible={3} duration={4500} position="top-right">
    <App />
  </ToastProvider>
</Theme>

// В App или его потомке:
const toast = useToast();
const id = toast.show({ tone: 'success', title: 'Сохранено', message: 'Готово' });
toast.show({ tone: 'error', title: 'Ошибка', message: 'Проверьте подключение' });
toast.show({ title: 'Элемент перемещён', duration: 0,
  action: { label: 'Отменить', onClick: undo } });
toast.dismiss(id);
toast.clear();
```

Provider располагается внутри Theme. useToast вне него выдаёт понятную ошибку. Возвращает show, dismiss, clear и count (видимые + ожидающие). show возвращает id.

- Визуал из NotificationItem: поверхность gray-900/95, цветная рамка 30%, SVG-иконка 20 px, прозрачный крестик 24 px; верхний и правый отступ крестика одинаковы — 16 px.
- tone: success / info / warning / error. У error время по умолчанию 0 (ручное закрытие); остальные наследуют duration провайдера. Явный duration имеет приоритет. duration=0 отключает автозакрытие.
- Очередь FIFO; таймер ожидающего сообщения начинается только после появления. maxVisible ограничивает показ, а не размер очереди.
- Наведение, фокус внутри уведомления и скрытая вкладка приостанавливают таймер с сохранением оставшегося времени.
- action вызывает переданный обработчик, затем закрывает сообщение. Асинхронный результат обработчика библиотека не отслеживает: передайте свою логику ожидания/ошибки при необходимости.
- Позиции: top-right (отступ сверху 64 px, как в исходнике) и bottom-right. Подписи региона и крестика задаются через label/closeLabel. Текст счётчика очереди в v1.2 русский.
- Provider выводит сообщения в обычном слое приложения; нативное модальное окно перекрывает этот слой. Для ошибок внутри активного Modal используйте Alert либо встроенный Toast внутри окна.

Отдельный Toast можно использовать без провайдера: передайте onDismiss и самостоятельно убирайте элемент из дерева. Его duration по умолчанию 0. Элемент с ошибкой имеет role=alert, остальные сообщения — role=status.

### Проверки

```sh
npm run showcase:build
npm install --no-save playwright
npx playwright install chromium
npm run test:interactions
npm run test:revision
npm run test:showcase
```

Проверены поиск, пустой результат, свободный текст, подсказки, меню с клавиатуры и мыши, фокус, таймеры/пауза/очередь, действия сообщений, мобильные границы и работа внутри Modal. Тесты используют Chromium. Реальные Electron-окна и экранный диктор отдельно не проверялись.


## Новое в 1.3: каркас приложения и числовой ввод

### Sidebar / MenuBar / StatusBar

Эти компоненты дополняют TitleBar и не зависят от Electron. Подключение к маршрутизации, файловой системе и командам окна остаётся в вашем приложении. Витрина содержит полный рабочий пример: меню добавляет записи, боковая панель переключает разделы, настройки связаны с числовыми контролами, строка состояния показывает результат.

```tsx
const [page, setPage] = useState('overview');
const [collapsed, setCollapsed] = useState(false);
const items = [
  {id:'overview',label:'Обзор',icon:<GridIcon />,group:'Проект'},
  {id:'projects',label:'Проекты',icon:<FolderIcon />,badge:3,group:'Проект'},
  {id:'settings',label:'Настройки',icon:<SettingsIcon />,group:'Приложение'},
];
<Sidebar label="Навигация" items={items} activeId={page} onActiveChange={setPage}
  collapsed={collapsed} onCollapsedChange={setCollapsed}
  header="МОЁ ПРИЛОЖЕНИЕ" footer="Локальная версия" />
```

Sidebar шириной 220 px, в свёрнутом виде 64 px. Сохраняет aria-label каждой кнопки, активный раздел имеет aria-current=page. items содержат уникальные id, label, необязательные icon, badge, disabled, group. Новый group рисует заголовок; одинаковые соседние group объединены визуально. Если icon отсутствует, используется первая буква label. onCollapsedChange необязателен: без него переключатель сворачивания не рисуется. Подписи кнопки задаются collapseLabel/expandLabel. Компонент не управляет историей маршрутов — это callback onActiveChange.

```tsx
const menus: MenuBarEntry[] = [
  {id:'file',label:'Файл',items:[
    {id:'new',label:'Новый проект',onSelect:create},
    {id:'save',label:'Сохранить',onSelect:save},
  ]},
  {id:'view',label:'Вид',items:[
    {id:'settings',label:'Настройки',onSelect:openSettings},
  ]},
];
<MenuBar label="Главное меню" menus={menus} />
```

MenuBar использует MenuItem из версии 1.2. Стрелки ←/→ перемещаются по верхней строке и переключают открытые меню. ↓ открывает меню на первом доступном пункте, ↑ — на последнем. Home/End работают в верхней строке и внутри меню; Enter/Space активируют пункт. Escape закрывает меню и возвращает фокус. Disabled-пропуск работает для пунктов и верхних меню. При открытом меню наведение на соседнее переключает меню. Автоматические Alt-акселераторы, вложенные подменю и регистрация глобальных shortcut не входят в 1.3. Это UI-меню для renderer, не системное меню macOS/Windows.

```tsx
<StatusBar message="Готово" items={[
  {id:'count',label:'3 проекта'},
  {id:'local',label:'Локально',tone:'success'},
  {id:'settings',label:'Настройки',onClick:openSettings},
]} />
```

StatusBar принимает message и items с id, label, icon, tone (neutral/success/warning/error), onClick. При наличии onClick рисуется button, иначе текст. Только message имеет role=status; остальные сегменты не образуют общий live-region. Строка переносится при нехватке ширины.

Пример общей компоновки — `showcase/DesktopDemo.tsx`. На узком экране витрина переводит Sidebar в горизонтальную навигацию; это CSS примера на container queries, а не принудительное поведение Sidebar во всех проектах.

### NumberInput

```tsx
const [volume, setVolume] = useState<number|null>(1.5);
<Field label="Объём, л">
  {props => <NumberInput {...props} value={volume} onValueChange={setVolume}
    min={0} max={10} step={0.25} unit="л" />}
</Field>
```

- Контролируемое поле: value — конечное число либо null. Использует текстовый input с role=spinbutton и customValidity, чтобы одинаково обрабатывать десятичную запятую и точку.
- Во время набора сохраняет черновик (`-`, `1,`, пустое значение). Для пустого или пока нечислового ввода onValueChange получает null; завершённый числовой ввод даёт number, даже если ещё вне границ.
- При blur допустимое число ограничивается min/max и округляется по step относительно min (либо 0 без min). Нечисловой черновик остаётся виден с aria-invalid и не проходит HTML-валидацию. Не считайте промежуточный null автоматическим согласием удалить данные: это состояние незавершённого поля.
- Кнопки −/+ и Arrow Up/Down меняют значение на шаг; Page Up/Down — на десять шагов. Home/End ставят min/max, если соответствующая граница задана. Кнопки на границах отключаются.
- name, required, disabled и readOnly поддерживаются. unit — визуальный суффикс: для доступности включите единицу измерения в label. decreaseLabel, increaseLabel и invalidMessage позволяют локализовать подписи.
- className/style относятся к внешней рамке; id, остальные атрибуты и ref — к input.
- Для расчётов используйте value из onValueChange. FormData читает текст поля, включая запятую до blur. Это обычный JavaScript Number, не decimal-библиотека для точной бухгалтерии; защита от двоичных погрешностей при шаге округляет до 12 знаков после запятой. Для сумм храните целые минимальные единицы или выполняйте точные расчёты отдельно.
- Указывайте конечные min/max, min≤max и положительный step, соответствующий масштабу данных. Некорректный step заменяется на 1. Поле контролируемое: сброс формы реализуется изменением value родителем.

### Slider

```tsx
const [memory, setMemory] = useState(2048);
<Slider aria-label="Лимит памяти" value={memory} onValueChange={setMemory}
  min={512} max={8192} step={128} showValue formatValue={v => `${v} МБ`} />
```

Визуал перенесён из MinecraftSettingsPanel: дорожка 8 px, ползунок 16 px, заполнение linear-gradient, исходный синий акцент. accent="theme" меняет его на основной цвет темы. Под капотом input type=range: нативные клавиши, name, disabled, ref. showValue выводит число справа, formatValue форматирует его и aria-valuetext. Поддерживаются value и defaultValue; для программного сброса используйте контролируемый value. Число выравнивается по шагу, min=max блокирует ввод. Если (max−min) не делится на step, доступна последняя ступень, не превышающая max. При подключении через Field его id передаётся ползунку.

### RadioGroup

```tsx
<RadioGroup label="Режим" value={mode} onValueChange={setMode}
  orientation="horizontal" options={[
    {value:'balanced',label:'Баланс',description:'Обычный режим'},
    {value:'fast',label:'Быстро'},
    {value:'locked',label:'Недоступно',disabled:true},
  ]} />
```

Рисует fieldset/legend и настоящие input type=radio с кастомным маркером 20 px. Выбор стрелками и отправка name=value реализуются браузером. Имя генерируется автоматически, если name не задан; при работе с формой передайте своё name. Общие disabled/required и disabled отдельных вариантов поддерживаются. Компоновки: vertical (по умолчанию), horizontal (с переносом). value — контролируемый режим; defaultValue — начальный выбор с внутренним состоянием. Внутренний режим восстанавливает defaultValue по form.reset(); в контролируемом сбрасывайте value в родителе. Значения options должны быть уникальными.

### Проверка 1.3

`npm run test:workspace`: переключение страниц, сворачивание Sidebar, команды и межменю-навигация MenuBar, сохранение настроек, связь NumberInput/Slider, запятая/границы/ошибки/клавиши, RadioGroup, интерактивный StatusBar и мобильная ширина. Проверяется и переполнение внутренней рабочей области, чтобы контент не скрывался за рамкой окна.


### Исправление 1.3.1

Убраны безусловные вызовы showPopover/hidePopover и селектора :popover-open. Dropdown, Select, Combobox, Tooltip, DropdownMenu, ContextMenu и MenuBar работают без Popover API. Fallback проверен в Chromium с отключёнными методами API и запретом селектора; настоящий старый браузер на Windows 7 не запускался.

### Исправление 1.3.2

Выбор в выпадающих элементах больше не перезапускает анимацию Modal в fallback-режиме. Анимация появления окна меняет только прозрачность; позиция и масштаб остаются стабильными. Переключение класса, разрешающего показ меню за границами окна, не меняет animation. Добавлен test:modal-stability с включёнными анимациями для native/fallback: сохранение DOM-узла, open, фокуса и данных формы; отсутствие повторного animationstart после выбора и закрытия подсказки.
