# Attribution

Visual source: EP Modpack Updater, provided archive ep-modpack-updater(1).zip.
Original package metadata: author ElectroPlay; license MIT.
This extraction preserves the visual palette and design patterns; components have been reimplemented for reusable use. No project logos, game content, user data, credentials or original Git history are included.

React is external in the installable library. The standalone catalog bundles React and React DOM under their MIT licenses; their license text is included in THIRD-PARTY-LICENSES.txt.
